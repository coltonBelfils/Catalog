create definer = FreeRadicals@`%` trigger before_insert_ranking
    before insert
    on ranking
    for each row
begin
    if new.ranking_id is null
    then
        set new.ranking_id = UUID();
    end if;
end;

