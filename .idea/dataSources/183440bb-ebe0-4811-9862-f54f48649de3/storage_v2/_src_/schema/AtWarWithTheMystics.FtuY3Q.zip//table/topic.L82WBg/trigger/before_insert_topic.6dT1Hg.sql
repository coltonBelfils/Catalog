create definer = FreeRadicals@`%` trigger before_insert_topic
    before insert
    on topic
    for each row
begin
    if new.topic_id is null
    then
        set new.topic_id = UUID();
    end if;
    IF new.date_created is null
    then
        set new.date_created = CURDATE();
    end if;
end;

