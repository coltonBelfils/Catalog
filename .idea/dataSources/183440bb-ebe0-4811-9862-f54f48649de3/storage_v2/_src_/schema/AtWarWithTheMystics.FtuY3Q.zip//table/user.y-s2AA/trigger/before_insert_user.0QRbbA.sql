create definer = FreeRadicals@`%` trigger before_insert_user
    before insert
    on user
    for each row
begin
    IF new.user_id is null
    then
        SET new.user_id = uuid();
    end if;
    IF new.date_created is null
    then
        set new.date_created = CURDATE();
    end if;
    end;

