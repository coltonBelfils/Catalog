create definer = FreeRadicals@`%` trigger before_insert_topic_admin
    before insert
    on topic_admin
    for each row
begin
    IF new.date_created is null
    then
        set new.date_created = CURDATE();
    end if;
end;

